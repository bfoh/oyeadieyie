PRESS KIT
Office of the Nkosuo Hene of Adrobaa
Tano North Municipal, Ahafo Region, Ghana

FORMS OF ADDRESS
  First reference: Nana Oyeadieyie Barima Essoun I, Nkosuo Hene of Adrobaa
  Later references: Nana Oyeadieyie
  In direct address: Nana

Nana is the honorific and is never dropped. Nkosuo Hene translates as Development Chief: the stool charged with attracting development to the town and accounting for it to the traditional council. It is not an honorary title. Confirm spellings with the office before publication.

BIOGRAPHY, SHORT
Nana Oyeadieyie Barima Essoun I is the Nkosuo Hene, or Development Chief, of Adrobaa in the Tano North Municipal district of Ghana's Ahafo Region. He is also a licensed precious metals dealer, running DeoMetals Ltd, a member of DGSC Group, whose trade underwrites his development work in the town.

BIOGRAPHY, LONG
Nana Oyeadieyie Barima Essoun I holds the Nkosuo stool of Adrobaa in Tano North Municipal, Ahafo Region. Where many traditional seats are ceremonial, the Nkosuo Hene carries an explicit brief: attract development to the town, deliver it, and account for it to the traditional council.

He pursues that brief on two fronts. As a chief he sits with the elders and queen mothers of Adrobaa, presides at durbars and festivals, and scopes every project with the council before funds move. As an executive he runs DeoMetals Ltd, a member of DGSC Group and a licensed precious metals dealer covering gold sourcing and purchasing, mining and refining operations, supply and export of minerals, trading, logistics and international distribution.

His stated agenda covers public sanitation, mechanised boreholes for clean drinking water, ring roads and street lighting, scholarships for brilliant but needy students, youth skills training, tree planting and community cleanliness. His own words for it: Development for the People, By the People.

TERMS OF USE
  - Editorial use is cleared for material in this pack.
  - Credit as: Office of the Nkosuo Hene of Adrobaa.
  - Commercial use requires written permission from the office.
  - Follow the forms of address above. Traditional titles carry protocol.
  - Images marked as a render are not photographs of completed work.

PHOTOGRAPHS (21)
  nana-oyeadieyie-regalia-umbrella.jpg
    Nana Oyeadieyie Barima Essoun I in adinkra cloth beneath the royal umbrella

  nana-oyeadieyie-kente-portrait.jpg
    Studio portrait in green and gold kente with gold bracelets

  nana-oyeadieyie-procession.jpg
    Procession in blue kente beneath the royal umbrella

  adrobaa-traditional-council.jpg
    Chiefs of Adrobaa seated in council

  nana-oyeadieyie-seated-kente.jpg
    Seated in blue and gold kente beneath the ceremonial umbrella, with family and attendants

  nana-oyeadieyie-deometals-field.jpg
    In DeoMetals field uniform reviewing documents at his desk

  nana-oyeadieyie-office-portrait.jpg
    Standing portrait in the office

  deometals-services.jpg
    DeoMetals Ltd banner listing its services

  nana-oyeadieyie-office-desk.jpg
    Standing at the office desk in black dress and red cap

  nana-oyeadieyie-travel.jpg
    Travelling on business for DeoMetals Ltd

  nana-oyeadieyie-international.jpg
    Abroad on the international trade lines

  nana-oyeadieyie-plaque-presentation.jpg
    Receiving a plaque at the office with colleagues

  borehole-drilling.jpg
    Drilling crew working the borehole rig

  groundbreaking-adrobaa.jpg
    Sod cutting before the chiefs and queen mothers

  community-cleanliness-distribution.jpg
    Women of Adrobaa receiving brooms and cleaning supplies

  sanitation-facility-render.jpg
    Architectural render of the public sanitation facility
    NOTE: Render, not a photograph

  sanitation-facility-render-aerial.jpg
    Architectural render of the sanitation facility seen from above
    NOTE: Render, not a photograph

  sanitation-foundation-poured.jpg
    Freshly poured concrete foundation trenches on the sanitation site

  sanitation-blockwork.jpg
    Site crew mixing concrete as the walls of the sanitation block rise

  sod-cutting-ceremony.jpg
    Cutting the sod before elders and queen mothers to open works

  community-gathering.jpg
    Chiefs, queen mothers and residents gathered on site under the umbrella
