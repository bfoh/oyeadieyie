PRESS KIT
Nana Oyeadieyie Barima Essoun I
Nkosuo Hene of Adrobaa, Tano North Municipal, Ahafo Region, Ghana

------------------------------------------------------------------
USE
Photography in this pack is cleared for editorial use with the credit
"Office of the Nkosuo Hene of Adrobaa". Commercial use requires written
permission. Traditional titles carry protocol; please follow the forms of
address below.

------------------------------------------------------------------
FORMS OF ADDRESS

First reference   Nana Oyeadieyie Barima Essoun I, Nkosuo Hene of Adrobaa
Later references  Nana Oyeadieyie
In direct address Nana

"Nana" is the honorific and is never dropped. "Nkosuo Hene" translates as
Development Chief: the stool charged with attracting development to the town
and accounting for it to the traditional council. It is not an honorary title.

Please confirm spellings with the office before publication.

------------------------------------------------------------------
SHORT BIOGRAPHY  (approx. 50 words)

Nana Oyeadieyie Barima Essoun I is the Nkosuo Hene, or Development Chief, of
Adrobaa in the Tano North Municipal district of Ghana's Ahafo Region. He is
also a licensed precious metals dealer, running DeoMetals Ltd, a member of
DGSC Group, whose trade underwrites his development work in the town.

------------------------------------------------------------------
LONG BIOGRAPHY  (approx. 150 words)

Nana Oyeadieyie Barima Essoun I holds the Nkosuo stool of Adrobaa in Tano
North Municipal, Ahafo Region. Where many traditional seats are ceremonial,
the Nkosuo Hene carries an explicit brief: attract development to the town,
deliver it, and account for it to the traditional council.

He pursues that brief on two fronts. As a chief he sits with the elders and
queen mothers of Adrobaa, presides at durbars and festivals, and scopes every
project with the council before funds move. As an executive he runs
DeoMetals Ltd, a member of DGSC Group and a licensed precious metals dealer
covering gold sourcing and purchasing, mining and refining operations, supply
and export of minerals, trading, logistics and international distribution.

His stated agenda covers public sanitation, mechanised boreholes for clean
drinking water, ring roads and street lighting, scholarships for brilliant but
needy students, youth skills training, tree planting and community
cleanliness. His own words for it: "Development for the People, By the People."

------------------------------------------------------------------
DEOMETALS LTD

A licensed precious metals dealer and a member of DGSC Group, describing
itself as a trusted partner in precious metals and global trade.

  Licensed precious metals dealer
  Gold sourcing and purchasing
  Mining and refining operations
  Supply and export of minerals
  General trading and logistics
  Import and international distribution

------------------------------------------------------------------
FILM

The enstoolment film is not included in this pack because of its size.
Broadcast quality copies are available from the press desk on request.

------------------------------------------------------------------
CONTACT

Office of the Nkosuo Hene, Adrobaa, Tano North Municipal, Ahafo Region, Ghana
Press desk: [PRESS EMAIL]
Office:     [OFFICIAL EMAIL] / [OFFICIAL PHONE]
